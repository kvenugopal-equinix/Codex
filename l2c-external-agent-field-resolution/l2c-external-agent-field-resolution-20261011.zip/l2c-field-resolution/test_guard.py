from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from guard import Status, resolve_price as production_resolve_price


FIXTURES = Path(__file__).resolve().parent / "fixtures"


def fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


def resolve_price(snapshot: dict):
    return production_resolve_price(snapshot, fixture_mode=True)


class PriceGuardTests(unittest.TestCase):
    def test_subset_fixture_requires_explicit_validation_mode(self) -> None:
        result = production_resolve_price(fixture("order-dmuat.json"))
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)

    def test_string_false_never_satisfies_evidence_booleans(self) -> None:
        mutations = (
            lambda s: s["lookup"].update(queried="false"),
            lambda s: s["lookup"]["matches"][0].update(exact_match="false"),
            lambda s: s.update(links_checked="false"),
            lambda s: s["line_set"].update(queried="false"),
            lambda s: s["line_set"].update(complete="false"),
            lambda s: s["discovery"]["header"].update(complete="false"),
        )
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                order = fixture("order-dmuat.json")
                mutate(order)
                result = resolve_price(order)
                self.assertNotEqual(result.status, Status.RESOLVED)
                self.assertFalse(result.amounts)

    def test_order_exact_linked_object_and_zero_quantity_lines(self) -> None:
        order = fixture("order-dmuat.json")
        self.assertEqual(len(order["lookup"]["matches"]), 2)  # Quote and Order share number
        self.assertTrue(all(line["quantity"] == "0" for line in order["line_set"]["lines"]))
        overage = order["line_set"]["lines"][-1]
        values = {c["metadata"]["api_name"]: c["observed"]["amount"] for c in overage["candidates"]}
        self.assertEqual((values["MRC__c"], values["NetUnitPrice"], values["TotalPrice"]),
                         ("0.65", "0.65", "0"))
        result = resolve_price(order)
        self.assertEqual(result.status, Status.RESOLVED)
        self.assertEqual((result.actual_object, result.record_id, result.revision),
                         ("Order", "801Qh00000lzr5yIAA", "1"))
        self.assertEqual({a.measure: (a.value, a.currency, a.basis) for a in result.amounts},
                         {"mrc": ("9451.37", "CAD", "as_recorded"),
                          "nrc": ("0.00", "CAD", "as_recorded")})

    def test_quote_only_number_can_resolve_verified_linked_order(self) -> None:
        order = fixture("order-dmuat.json")
        order["lookup"]["matches"] = [m for m in order["lookup"]["matches"] if m["object"] == "Quote"]
        result = resolve_price(order)
        self.assertEqual(result.status, Status.RESOLVED)
        self.assertEqual((result.actual_object, result.record_id), ("Order", "801Qh00000lzr5yIAA"))
        broken = copy.deepcopy(order)
        broken["links"] = []
        self.assertEqual(resolve_price(broken).status, Status.AMBIGUOUS)

    def test_quote_scoped_zero_is_not_overall_zero(self) -> None:
        quote = fixture("quote-dmuat.json")
        self.assertEqual(next(c for c in quote["header_candidates"] if c["metadata"]["api_name"] == "GrandTotal")
                         ["observed"]["amount"], "99784")
        result = resolve_price(quote)
        self.assertEqual(result.status, Status.RESOLVED)
        self.assertEqual({a.measure: a.value for a in result.amounts},
                         {"mrc": "0.00", "nrc": "37754.00"})
        quote["request"]["measures"] = ["total_price"]
        generic = resolve_price(quote)
        self.assertEqual(generic.status, Status.AMBIGUOUS)
        self.assertFalse(generic.amounts)

    def test_discovered_custom_field_must_be_fetched_before_standard_claim(self) -> None:
        quote = fixture("quote-dmuat.json")
        quote["request"]["measures"] = ["total_price"]
        mrc = next(c for c in quote["header_candidates"] if c["metadata"]["api_name"] == "Total_MRC__c")
        mrc["observed"] = {"state": "unqueried"}
        result = resolve_price(quote)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("Total_MRC__c" in query for query in result.queries))

    def test_manifest_missing_custom_field_requires_query(self) -> None:
        quote = fixture("quote-dmuat.json")
        quote["header_candidates"] = [c for c in quote["header_candidates"]
                                      if c["metadata"]["api_name"] != "Total_MRC__c"]
        result = resolve_price(quote)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertTrue(any("Total_MRC__c" in query for query in result.queries))

    def test_line_inventory_metadata_conflict_is_ambiguous(self) -> None:
        order = fixture("order-dmuat.json")
        inventory_field = next(item for item in order["discovery"]["line"]["inventory_pricing_fields"]
                               if item["api_name"] == "Cumulative_MRC__c")
        inventory_field.update(data_type="Formula", formula="1")
        result = resolve_price(order)
        self.assertEqual(result.status, Status.AMBIGUOUS)
        self.assertFalse(result.amounts)
        self.assertTrue(any("metadata conflicts" in issue for issue in result.issues))

    def test_even_context_only_candidate_must_be_read(self) -> None:
        order = fixture("order-dmuat.json")
        duplicate = next(c for c in order["header_candidates"]
                         if c["metadata"]["api_name"] == "Total_Recurring_Charges__c")
        duplicate["observed"] = {"state": "unqueried"}
        result = resolve_price(order)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("Total_Recurring_Charges__c" in query for query in result.queries))

    def test_rollup_header_requires_complete_source_lines(self) -> None:
        order = fixture("order-dmuat.json")
        order.pop("line_set")
        result = resolve_price(order)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("rollup source lines" in query for query in result.queries))

    def test_verified_empty_rollup_source_preserves_zero(self) -> None:
        order = fixture("order-dmuat.json")
        for candidate in order["header_candidates"][:2]:
            candidate["observed"].update(state="zero", amount="0")
        order["line_set"]["lines"] = []
        order["line_set"]["expected_count"] = 0
        order["line_set"]["count_evidence"].update(total_size=0, record_ids=[])
        result = resolve_price(order)
        self.assertEqual(result.status, Status.RESOLVED)
        self.assertEqual({a.measure: a.value for a in result.amounts}, {"mrc": "0.00", "nrc": "0.00"})

    def test_truncated_line_only_result_requires_server_count_evidence(self) -> None:
        order = fixture("order-dmuat.json")
        order["header_candidates"][0]["mapping"]["role"] = "context_only"
        root = next(line for line in order["line_set"]["lines"] if line["inclusion"]["mrc"] == "include")
        order["line_set"]["lines"] = [root]
        order["line_set"]["expected_count"] = 1
        result = resolve_price(order)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("totalSize" in query for query in result.queries))

    def test_duplicate_line_ids_cannot_be_summed(self) -> None:
        order = fixture("order-dmuat.json")
        order["header_candidates"][0]["mapping"]["role"] = "context_only"
        lines = order["line_set"]["lines"]
        lines[2] = copy.deepcopy(lines[1])
        result = resolve_price(order)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("duplicate record IDs" in issue for issue in result.issues))

    def test_multiple_primary_line_fields_are_not_double_counted(self) -> None:
        order = fixture("order-dmuat.json")
        root = next(line for line in order["line_set"]["lines"] if line["inclusion"]["mrc"] == "include")
        primary = next(c for c in root["candidates"] if c["metadata"]["api_name"] == "Cumulative_MRC__c")
        root["candidates"].append(copy.deepcopy(primary))
        result = resolve_price(order)
        self.assertEqual(result.status, Status.AMBIGUOUS)
        self.assertFalse(result.amounts)
        self.assertTrue(any("multiple primary" in issue for issue in result.issues))

    def test_soql_aggregate_cannot_be_labeled_record_currency(self) -> None:
        order = fixture("order-dmuat.json")
        mrc = next(c for c in order["header_candidates"] if c["metadata"]["api_name"] == "Total_MRC__c")
        mrc["observed"].update(state="value", amount="6790.73", source="soql_aggregate",
                               currency="CAD", currency_provenance="unconverted_record")
        result = resolve_price(order)
        self.assertEqual(result.status, Status.NEEDS_QUERY)
        self.assertFalse(result.amounts)
        self.assertTrue(any("SOQL" in query for query in result.queries))

    def test_duplicate_label_and_null_do_not_override_rollup(self) -> None:
        order = fixture("order-dmuat.json")
        header = order["header_candidates"]
        self.assertEqual(header[0]["metadata"]["label"], header[2]["metadata"]["label"])
        self.assertEqual(header[1]["metadata"]["label"], header[3]["metadata"]["label"])
        self.assertEqual(header[3]["observed"]["state"], "null")
        self.assertEqual(resolve_price(order).status, Status.RESOLVED)
        bad = copy.deepcopy(order)
        bad["header_candidates"][0]["mapping"]["evidence"] = []
        self.assertEqual(resolve_price(bad).status, Status.AMBIGUOUS)

    def test_unverified_net_basis_and_wrong_revision_are_rejected(self) -> None:
        order = fixture("order-dmuat.json")
        order["header_candidates"][0]["mapping"]["basis"] = "net"
        self.assertEqual(resolve_price(order).status, Status.AMBIGUOUS)
        wrong = fixture("order-dmuat.json")
        wrong["request"]["revision"] = "2"
        self.assertEqual(resolve_price(wrong).status, Status.AMBIGUOUS)

    def test_mislabeled_order_number_surfaces_actual_quote_object(self) -> None:
        quote = fixture("quote-dmuat.json")
        quote["request"]["target_object"] = "Order"
        quote["target"] = {"object": "Order", "record_id": "unverified", "revision": "1",
                           "revision_evidence": "unverified"}
        result = resolve_price(quote)
        self.assertEqual(result.status, Status.AMBIGUOUS)
        self.assertEqual((result.actual_object, result.record_id), ("Quote", "0Q0Ek00000B79jOKAR"))


if __name__ == "__main__":
    unittest.main()
