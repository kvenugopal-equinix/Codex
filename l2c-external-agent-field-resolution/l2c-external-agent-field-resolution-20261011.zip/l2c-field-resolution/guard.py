"""Read-only, agent-neutral guard for Salesforce transaction price claims.

The caller supplies a normalized snapshot of Salesforce query results and
field-resolution evidence. This module never calls Salesforce or SharePoint.
It returns amounts only when *all* requested measures can be resolved.
"""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from enum import Enum
from pathlib import Path
from typing import Any, Mapping


class Status(str, Enum):
    RESOLVED = "resolved"
    NEEDS_QUERY = "needs_query"
    AMBIGUOUS = "ambiguous"


@dataclass(frozen=True)
class Amount:
    measure: str
    value: str
    currency: str
    basis: str
    scope: str
    supporting_fields: tuple[str, ...]


@dataclass(frozen=True)
class Resolution:
    status: Status
    actual_object: str | None
    record_id: str | None
    revision: str | None
    amounts: tuple[Amount, ...] = ()
    queries: tuple[str, ...] = ()
    issues: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["status"] = self.status.value
        return result


def _dict(value: Any) -> dict[str, Any]:
    return dict(value) if isinstance(value, Mapping) else {}


def _list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, list) else []


def _nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _decimal(value: Any) -> Decimal | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        number = Decimal(str(value))
        return number if number.is_finite() else None
    except (InvalidOperation, ValueError):
        return None


def _plain(number: Decimal) -> str:
    return format(number, "f")


def _identity(snapshot: dict[str, Any], queries: list[str], issues: list[str]) -> dict[str, Any]:
    request = _dict(snapshot.get("request"))
    lookup = _dict(snapshot.get("lookup"))
    target = _dict(snapshot.get("target"))
    identifier = request.get("identifier")
    if not _nonempty(identifier):
        issues.append("The requested transaction identifier is absent.")
    if lookup.get("queried") is not True:
        queries.append("Query Salesforce by the supplied transaction number or record ID first.")
    elif lookup.get("identifier") != identifier:
        issues.append("The Salesforce lookup did not use the exact supplied identifier.")

    matches = [_dict(item) for item in _list(lookup.get("matches"))]
    target_object = request.get("target_object")
    selected_matches = [item for item in matches if item.get("object") == target_object] if _nonempty(target_object) else matches
    via_link = False
    if _nonempty(target_object) and not selected_matches and snapshot.get("links_checked") is True:
        links = [_dict(item) for item in _list(snapshot.get("links"))]
        linked_matches = []
        for match in matches:
            if match.get("exact_match") is not True:
                continue
            for item in links:
                if item.get("verified") is not True:
                    continue
                forward = (item.get("from_object"), item.get("from_record_id"), str(item.get("from_revision")),
                           item.get("to_object"), item.get("to_record_id"), str(item.get("to_revision")))
                expected = (match.get("object"), match.get("record_id"), str(match.get("revision")),
                            target.get("object"), target.get("record_id"), str(target.get("revision")))
                reverse_expected = expected[3:] + expected[:3]
                if forward == expected or forward == reverse_expected:
                    linked_matches.append(match)
                    break
        if len(linked_matches) == 1:
            selected_matches = linked_matches
            via_link = True
    if lookup.get("queried") is True:
        if len(selected_matches) != 1:
            if not selected_matches and snapshot.get("links_checked") is not True and matches:
                queries.append("Query exact links and revisions from the matched object to the requested target object.")
            else:
                issues.append(f"The supplied identifier has {len(selected_matches)} verified matches or links to the requested target object; resolve the exact object and record.")
        elif selected_matches[0].get("exact_match") is not True:
            issues.append("The matched Salesforce record is not an exact identifier match.")

    if not all(_nonempty(target.get(key)) for key in ("object", "record_id", "revision")):
        queries.append("Read the exact target object, record ID, and applicable revision.")
    if _nonempty(target_object) and _nonempty(target.get("object")) and target_object != target.get("object"):
        issues.append("The selected target object does not match the object requested for the answer.")
    requested_revision = request.get("revision")
    if requested_revision is not None and str(requested_revision) != str(target.get("revision")):
        issues.append("The target is a different revision from the one requested.")
    if not _nonempty(target.get("revision_evidence")):
        queries.append("Verify the target revision from the record or a linked revision-bearing record.")

    if snapshot.get("links_checked") is not True:
        queries.append("Query and verify transaction links and their revisions.")
    if len(selected_matches) == 1 and target.get("record_id") and target.get("object") and target.get("revision"):
        match = selected_matches[0]
        same = (match.get("object"), match.get("record_id"), str(match.get("revision"))) == (
            target.get("object"), target.get("record_id"), str(target.get("revision")))
        if not same and _nonempty(target_object) and not via_link:
            issues.append("The selected target is not the exact record matched for the requested object.")
        if not same and snapshot.get("links_checked") is True:
            links = [_dict(item) for item in _list(snapshot.get("links"))]
            expected = (match.get("object"), match.get("record_id"), str(match.get("revision")),
                        target.get("object"), target.get("record_id"), str(target.get("revision")))
            linked = [item for item in links if item.get("verified") is True and
                      (item.get("from_object"), item.get("from_record_id"), str(item.get("from_revision")),
                       item.get("to_object"), item.get("to_record_id"), str(item.get("to_revision")))
                      in (expected, expected[3:] + expected[:3])]
            if len(linked) != 1:
                issues.append("The target record and revision are not verified as the exact linked transaction.")
        if same and snapshot.get("links_checked") is True:
            links = [_dict(item) for item in _list(snapshot.get("links"))]
            for related in matches:
                if related is match:
                    continue
                if related.get("exact_match") is not True:
                    issues.append("A related record with the same identifier was not an exact match.")
                    continue
                endpoints = {(item.get("from_object"), item.get("from_record_id"), str(item.get("from_revision")),
                              item.get("to_object"), item.get("to_record_id"), str(item.get("to_revision")))
                             for item in links if item.get("verified") is True}
                forward = (related.get("object"), related.get("record_id"), str(related.get("revision")),
                           target.get("object"), target.get("record_id"), str(target.get("revision")))
                reverse = (target.get("object"), target.get("record_id"), str(target.get("revision")),
                           related.get("object"), related.get("record_id"), str(related.get("revision")))
                if forward not in endpoints and reverse not in endpoints:
                    issues.append("Records sharing the transaction number lack a verified exact revision link.")
    return target


def _mapping_ok(candidate: dict[str, Any], metric: str, issues: list[str]) -> bool:
    metadata = _dict(candidate.get("metadata"))
    mapping = _dict(candidate.get("mapping"))
    api = metadata.get("api_name", "<unnamed field>")
    required_metadata = {"api_name", "label", "description", "help_text", "data_type", "formula", "rollup", "relationship"}
    if not required_metadata.issubset(metadata) or not _nonempty(metadata.get("api_name")) or not _nonempty(metadata.get("data_type")):
        issues.append(f"{api}: Salesforce field metadata is incomplete.")
        return False
    if metadata.get("data_type") not in ("Currency", "Summary", "Formula") and mapping.get("role") != "context_only":
        issues.append(f"{api}: metadata type does not establish a monetary value.")
        return False
    if mapping.get("measure") != metric:
        issues.append(f"{api}: business measure is unverified for {metric}.")
        return False
    if mapping.get("role") not in ("primary", "cross_check", "context_only") or not _nonempty(mapping.get("meaning")):
        issues.append(f"{api}: mapping role or business meaning is unverified.")
        return False
    if mapping.get("role") != "context_only":
        if mapping.get("basis") not in ("net", "gross", "as_recorded") or mapping.get("amount_kind") not in (
            "document_total", "extended_charge", "rate", "unit_price"):
            issues.append(f"{api}: price basis or rate/charge meaning is unverified.")
            return False
    refs = [_dict(ref) for ref in _list(mapping.get("evidence"))]
    sources = {ref.get("source") for ref in refs if _nonempty(ref.get("detail"))}
    if "sharepoint_mapping" not in sources and not {"salesforce_metadata", "transaction_pricing"}.issubset(sources):
        issues.append(f"{api}: mapping needs a specific SharePoint mapping or Salesforce metadata plus transaction pricing evidence.")
        return False
    if metadata.get("formula") and "formula_definition" not in sources:
        issues.append(f"{api}: inspect the formula definition before using its value.")
        return False
    if metadata.get("rollup") and "rollup_definition" not in sources:
        issues.append(f"{api}: inspect the rollup source field and filters before using its value.")
        return False
    if mapping.get("role") != "context_only" and mapping.get("basis") in ("net", "gross") and "basis_definition" not in sources:
        issues.append(f"{api}: {mapping.get('basis')} basis lacks specific source evidence.")
        return False
    if mapping.get("role") != "context_only" and mapping.get("basis") == "as_recorded" and "rollup_definition" not in sources:
        issues.append(f"{api}: as-recorded rollup scope lacks the source-field and filter definition.")
        return False
    return True


def _observed_amount(candidate: dict[str, Any], record_currency: str,
                     queries: list[str], issues: list[str]) -> Decimal | None:
    metadata = _dict(candidate.get("metadata"))
    api = metadata.get("api_name", "<unnamed field>")
    observed = _dict(candidate.get("observed"))
    state = observed.get("state")
    if state in ("unqueried", "omitted", "missing") or not state:
        queries.append(f"Query {api} on the exact record/revision; its value is {state or 'unspecified'}.")
        return None
    if state == "inaccessible":
        issues.append(f"{api} is inaccessible; do not infer its value.")
        return None
    if state == "null":
        issues.append(f"{api} is null; null is not zero.")
        return None
    if state not in ("zero", "value"):
        issues.append(f"{api} has an invalid value state.")
        return None
    number = _decimal(observed.get("amount"))
    if number is None or (state == "zero" and number != 0) or (state == "value" and number == 0):
        issues.append(f"{api} value and explicit state disagree.")
        return None
    if observed.get("source") == "soql_aggregate":
        queries.append(f"Fetch unconverted per-record {api}; a SOQL currency aggregate has no verified record currency.")
        return None
    if observed.get("source") != "raw_field" or observed.get("currency_provenance") != "unconverted_record":
        queries.append(f"Verify the unconverted record-currency source of {api}.")
        return None
    if observed.get("currency") != record_currency:
        queries.append(f"Reconcile {api} currency with the target record currency {record_currency}.")
        return None
    return number


def _candidate_applies(candidate: dict[str, Any], metric: str) -> bool:
    mapping = _dict(candidate.get("mapping"))
    if mapping.get("role") == "context_only":
        return False
    return bool(metric in _list(candidate.get("potential_measures")) or mapping.get("measure") == metric)


def _check_discovery(snapshot: dict[str, Any], target: dict[str, Any],
                     queries: list[str], issues: list[str], *, fixture_mode: bool) -> None:
    """Require a metadata-derived manifest, including observed custom candidates."""
    discovery = _dict(snapshot.get("discovery"))
    for scope, candidates in (("header", _list(snapshot.get("header_candidates"))),
                              ("line", [_dict(c) for line in _list(_dict(snapshot.get("line_set")).get("lines"))
                                        for c in _list(_dict(line).get("candidates"))])):
        if scope == "line" and not _dict(snapshot.get("line_set")):
            continue
        manifest = _dict(discovery.get(scope))
        production_manifest = (manifest.get("source") == "salesforce_describe_and_customfield_metadata" and
                               manifest.get("inventory_source") == "full_sobject_describe_plus_customfield_metadata")
        fixture_manifest = (fixture_mode and snapshot.get("fixture_attestation") == "known_relevant_dmuat_subset" and
                            manifest.get("source") == "saved_read_only_investigation_subset" and
                            manifest.get("inventory_source") == "known_relevant_dmuat_subset")
        if manifest.get("complete") is not True or not (production_manifest or fixture_manifest):
            queries.append(f"Complete Salesforce Describe/CustomField pricing-field discovery for the {scope} object.")
            continue
        if scope == "header" and (manifest.get("object") != target.get("object") or
                                   manifest.get("record_id") != target.get("record_id") or
                                   str(manifest.get("revision")) != str(target.get("revision"))):
            issues.append("Header metadata discovery is for another target object, record, or revision.")
        if scope == "line" and manifest.get("object") != _dict(snapshot.get("line_set")).get("object"):
            issues.append("Line metadata discovery object does not match the queried line object.")
        names = _list(manifest.get("candidate_api_names"))
        if not names or len(names) != len(set(names)) or any(not _nonempty(name) for name in names):
            queries.append(f"Provide the complete unique {scope} pricing candidate API-name list from metadata.")
            continue
        inventory = [_dict(item) for item in _list(manifest.get("inventory_pricing_fields"))]
        inventory_names = [item.get("api_name") for item in inventory]
        if (not inventory or manifest.get("inventory_field_count") != len(inventory) or
                len(set(inventory_names)) != len(inventory_names) or
                not (production_manifest or fixture_manifest)):
            queries.append(f"Provide complete {scope} pricing-field metadata inventory from Salesforce Describe and CustomField metadata.")
        elif set(inventory_names) != set(names):
            queries.append(f"Reconcile {scope} candidate list with the metadata pricing-field inventory.")
        if scope == "header":
            actual = [_dict(c.get("metadata")).get("api_name") for c in map(_dict, candidates)]
            missing = set(names) - set(actual)
            if missing:
                queries.append(f"Read discovered header pricing fields omitted from the snapshot: {', '.join(sorted(missing))}.")
            if set(actual) - set(names):
                issues.append("Header candidate observations are not reconciled to the metadata discovery manifest.")
            by_name = {_dict(c.get("metadata")).get("api_name"): _dict(c.get("metadata")) for c in map(_dict, candidates)}
            for item in inventory:
                api = item.get("api_name")
                if api in by_name and (item.get("data_type"), item.get("rollup"), item.get("formula")) != (
                        by_name[api].get("data_type"), by_name[api].get("rollup"), by_name[api].get("formula")):
                    issues.append(f"{api}: observed metadata conflicts with the discovery inventory.")
        else:
            for line in _list(_dict(snapshot.get("line_set")).get("lines")):
                line = _dict(line)
                by_name = {_dict(c.get("metadata")).get("api_name"): _dict(c.get("metadata"))
                           for c in map(_dict, _list(line.get("candidates")))}
                missing = set(names) - set(by_name)
                if missing:
                    queries.append(f"Read discovered line pricing fields on {line.get('record_id')}: {', '.join(sorted(missing))}.")
                for item in inventory:
                    api = item.get("api_name")
                    if api in by_name and (item.get("data_type"), item.get("rollup"), item.get("formula")) != (
                            by_name[api].get("data_type"), by_name[api].get("rollup"), by_name[api].get("formula")):
                        issues.append(f"{api} on line {line.get('record_id')}: observed metadata conflicts with the discovery inventory.")
        for candidate in map(_dict, candidates):
            state = _dict(candidate.get("observed")).get("state")
            if state in ("unqueried", "omitted", "missing"):
                queries.append(f"Fetch discovered pricing field {_dict(candidate.get('metadata')).get('api_name')} before any price claim; state is {state}.")
            if state not in (
                "zero", "value", "null", "unqueried", "inaccessible", "omitted", "missing"):
                queries.append(f"Record the explicit value state for {_dict(candidate.get('metadata')).get('api_name')}.")


def _check_currency(snapshot: dict[str, Any], target: dict[str, Any],
                    queries: list[str], issues: list[str]) -> str:
    evidence = _dict(snapshot.get("currency_evidence"))
    code = snapshot.get("record_currency")
    if not _nonempty(code):
        queries.append("Read CurrencyIsoCode for the exact target record.")
    if (evidence.get("record_id") != target.get("record_id") or
            str(evidence.get("revision")) != str(target.get("revision")) or
            evidence.get("field_api_name") != "CurrencyIsoCode" or
            evidence.get("source") != "raw_field" or
            evidence.get("currency") != code):
        queries.append("Verify record currency from CurrencyIsoCode on the exact target record/revision.")
    return str(code)


def _candidate_value(candidate: dict[str, Any], metric: str, target: dict[str, Any],
                     record_currency: str, queries: list[str], issues: list[str],
                     *, line_id: str | None = None) -> tuple[Decimal, str, str, str, str] | None:
    metadata = _dict(candidate.get("metadata"))
    api = metadata.get("api_name", "<unnamed field>")
    expected_id = line_id or target.get("record_id")
    if candidate.get("record_id") != expected_id or str(candidate.get("revision")) != str(target.get("revision")):
        issues.append(f"{api}: value belongs to another record or revision.")
        return None
    if _dict(candidate.get("observed")).get("state") in ("unqueried", "omitted", "missing"):
        queries.append(f"Query {api} on the exact record/revision before resolving {metric}.")
        return None
    if not _mapping_ok(candidate, metric, issues):
        return None
    mapping = _dict(candidate.get("mapping"))
    kind = mapping.get("amount_kind")
    if kind in ("rate", "unit_price"):
        return None  # known rate, never an extended total
    if line_id is not None and kind != "extended_charge":
        issues.append(f"{api}: a line contribution must be an extended charge.")
        return None
    if line_id is None and kind != "document_total":
        issues.append(f"{api}: a header contribution must be a document total.")
        return None
    number = _observed_amount(candidate, record_currency, queries, issues)
    if number is None:
        return None
    return number, str(mapping.get("basis")), str(api), str(mapping.get("role")), str(mapping.get("meaning"))


def _verified_line_set(line_set: dict[str, Any], target: dict[str, Any],
                       queries: list[str], issues: list[str]) -> bool:
    if line_set.get("queried") is not True or line_set.get("complete") is not True:
        queries.append("Fetch the complete line set for the target record and revision.")
        return False
    lines = [_dict(line) for line in _list(line_set.get("lines"))]
    ids = [line.get("record_id") for line in lines]
    if any(not _nonempty(line_id) for line_id in ids) or len(ids) != len(set(ids)):
        issues.append("The line set has missing or duplicate record IDs; it cannot be summed.")
        return False
    evidence = _dict(line_set.get("count_evidence"))
    count = evidence.get("total_size")
    if (not isinstance(count, int) or isinstance(count, bool) or
            not isinstance(line_set.get("expected_count"), int) or isinstance(line_set.get("expected_count"), bool) or
            count != line_set.get("expected_count") or count != len(lines) or
            evidence.get("source") != "salesforce_query_totalSize" or
            evidence.get("pages_complete") is not True or
            evidence.get("object") != line_set.get("object") or
            evidence.get("parent_record_id") != target.get("record_id") or
            str(evidence.get("revision")) != str(target.get("revision")) or
            not _nonempty(evidence.get("parent_lookup_field")) or
            _list(evidence.get("record_ids")) != ids):
        queries.append("Verify complete Salesforce line pagination, totalSize, unique row IDs, parent filter, and revision.")
        return False
    return True


def _line_values(snapshot: dict[str, Any], metric: str, target: dict[str, Any],
                 record_currency: str, queries: list[str], issues: list[str]) -> list[tuple[Decimal, str, str, str, str]]:
    line_set = _dict(snapshot.get("line_set"))
    if not line_set:
        return []
    if not _verified_line_set(line_set, target, queries, issues):
        return []
    lines = [_dict(line) for line in _list(line_set.get("lines"))]
    if not any(_candidate_applies(_dict(candidate), metric) and
               _dict(_dict(candidate).get("mapping")).get("role") != "context_only"
               for line in lines for candidate in _list(line.get("candidates"))):
        return []
    values: list[tuple[Decimal, str, str, str, str]] = []
    included_by_group: dict[str, set[str]] = {}
    for line in lines:
        line_id = line.get("record_id")
        if not _nonempty(line_id) or line.get("parent_record_id") != target.get("record_id") or str(line.get("revision")) != str(target.get("revision")):
            issues.append("A line is not linked to the exact target record/revision.")
            continue
        if _decimal(line.get("quantity")) is None:
            queries.append(f"Read and verify quantity on line {line_id}.")
        inclusion = _dict(line.get("inclusion")).get(metric)
        if inclusion not in ("include", "exclude") or not _nonempty(line.get("inclusion_evidence")):
            queries.append(f"Verify eligibility and inclusion evidence for {metric} on line {line_id}.")
            continue
        bundle = line.get("bundle_treatment")
        if bundle not in ("standalone", "parent_amount", "child_amount", "excluded_component"):
            queries.append(f"Verify bundle treatment on line {line_id}.")
            continue
        if inclusion == "exclude":
            continue
        if bundle == "excluded_component":
            issues.append(f"Line {line_id} is both included and an excluded bundle component.")
            continue
        group = line.get("bundle_group")
        if group and bundle in ("parent_amount", "child_amount"):
            included_by_group.setdefault(str(group), set()).add(str(bundle))
        applicable = [c for c in map(_dict, _list(line.get("candidates"))) if _candidate_applies(c, metric)]
        extended = [c for c in applicable if _dict(c.get("mapping")).get("amount_kind") == "extended_charge"]
        if not extended:
            queries.append(f"Read a verified extended {metric} amount on included line {line_id}; unit or usage rates cannot be summed.")
        primary_extended = [c for c in extended if _dict(c.get("mapping")).get("role") == "primary"]
        if len(primary_extended) > 1:
            issues.append(f"Line {line_id} has multiple primary extended {metric} fields; resolve their business relationship before summing.")
        for candidate in applicable:
            value = _candidate_value(candidate, metric, target, record_currency, queries, issues, line_id=str(line_id))
            if value is not None:
                values.append(value)
    for group, roles in included_by_group.items():
        if {"parent_amount", "child_amount"}.issubset(roles):
            issues.append(f"Bundle {group} includes both parent and child amounts; verify allocation before summing.")
    return values


def resolve_price(snapshot: Mapping[str, Any], *, fixture_mode: bool = False) -> Resolution:
    """Resolve requested measures from a normalized, read-only evidence snapshot.

    ``amounts`` is empty unless every requested measure is resolved. ``issues``
    means competing or invalid evidence; ``queries`` names missing read-only
    evidence. Ambiguity takes precedence if both occur.
    """
    data = _dict(snapshot)
    queries: list[str] = []
    issues: list[str] = []
    target = _identity(data, queries, issues)
    identity_issue_count = len(issues)
    request = _dict(data.get("request"))
    measures = _list(request.get("measures"))
    if not measures or any(not _nonempty(metric) for metric in measures) or len(set(measures)) != len(measures):
        issues.append("Specify distinct business price measures; a generic total needs an explicit verified mapping.")
    _check_discovery(data, target, queries, issues, fixture_mode=fixture_mode)
    record_currency = _check_currency(data, target, queries, issues)
    provisional: list[Amount] = []
    header = [_dict(candidate) for candidate in _list(data.get("header_candidates"))]
    for metric in measures:
        if not _nonempty(metric):
            continue
        applicable = [candidate for candidate in header if _candidate_applies(candidate, metric)]
        selected_header: list[tuple[Decimal, str, str, str, str]] = []
        for candidate in applicable:
            value = _candidate_value(candidate, metric, target, str(record_currency), queries, issues)
            if value is not None:
                selected_header.append(value)
        selected_lines = _line_values(data, metric, target, str(record_currency), queries, issues)
        primary = [value for value in selected_header + selected_lines if value[3] == "primary"]
        checks = [value for value in selected_header + selected_lines if value[3] == "cross_check"]
        if not primary:
            if not queries:
                issues.append(f"No verified primary {metric} mapping establishes a reportable amount.")
            continue
        bases = {item[1] for item in primary + checks}
        if len(bases) != 1:
            issues.append(f"{metric} mixes price bases.")
            continue
        basis = bases.pop()
        requested_basis = request.get("basis")
        if requested_basis is not None and requested_basis != basis:
            issues.append(f"{metric} is {basis}, while the requested basis is {requested_basis}.")
            continue
        header_primary = [item for item in selected_header if item[3] == "primary"]
        line_primary = [item for item in selected_lines if item[3] == "primary"]
        if header_primary and any(_dict(c.get("metadata")).get("rollup") and
                                  _dict(c.get("mapping")).get("role") == "primary" for c in applicable) and not line_primary:
            line_set = _dict(data.get("line_set"))
            complete = _verified_line_set(line_set, target, queries, issues)
            lines = [_dict(line) for line in _list(line_set.get("lines"))]
            no_eligible_lines = complete and all(_dict(line.get("inclusion")).get(metric) == "exclude" and
                                                 _nonempty(line.get("inclusion_evidence")) for line in lines)
            if no_eligible_lines and all(item[0] == 0 for item in header_primary):
                pass  # verified empty rollup source, so the exact header zero is meaningful
            elif no_eligible_lines:
                issues.append(f"{metric} rollup is nonzero although no eligible source lines were returned.")
                continue
            else:
                queries.append(f"Read complete eligible {metric} rollup source lines and reconcile them to the header.")
                continue
        if len(header_primary) > 1 and len({item[0] for item in header_primary}) > 1:
            issues.append(f"Competing verified {metric} header totals disagree.")
            continue
        header_value = header_primary[0][0] if header_primary else None
        line_value = sum((item[0] for item in line_primary), Decimal(0)) if line_primary else None
        if header_value is not None and line_value is not None and header_value != line_value:
            issues.append(f"Verified {metric} header and line totals disagree; inspect rollup filters and bundle treatment.")
            continue
        result_value = header_value if header_value is not None else line_value
        if result_value is None:
            continue
        if any(check[0] != result_value for check in checks):
            issues.append(f"A verified {metric} cross-check differs from the primary amount.")
            continue
        currency_scale = data.get("currency_scale")
        if currency_scale is not None:
            if not isinstance(currency_scale, int) or isinstance(currency_scale, bool) or not 0 <= currency_scale <= 6:
                issues.append("The target currency display scale is invalid or unverified.")
                continue
            scale_evidence = _dict(data.get("currency_scale_evidence"))
            if scale_evidence.get("source") not in ("salesforce_currency_metadata", "salesforce_field_display") or not _nonempty(scale_evidence.get("detail")):
                queries.append("Verify currency display scale from Salesforce metadata or field display.")
                continue
            result_value = result_value.quantize(Decimal(1).scaleb(-currency_scale), rounding=ROUND_HALF_UP)
        scope = header_primary[0][4] if header_primary else line_primary[0][4]
        provisional.append(Amount(str(metric), _plain(result_value), str(record_currency), basis,
                                  scope, tuple(item[2] for item in primary)))
    if identity_issue_count:
        status = Status.AMBIGUOUS
    elif queries:
        status = Status.NEEDS_QUERY
    elif issues:
        status = Status.AMBIGUOUS
    elif len(provisional) != len(measures):
        status = Status.AMBIGUOUS
    else:
        status = Status.RESOLVED
    output_target = target
    lookup_matches = [_dict(item) for item in _list(_dict(data.get("lookup")).get("matches"))]
    if status != Status.RESOLVED and len(lookup_matches) == 1 and lookup_matches[0].get("exact_match") is True and (
            lookup_matches[0].get("object"), lookup_matches[0].get("record_id")) != (
            target.get("object"), target.get("record_id")):
        output_target = lookup_matches[0]
    return Resolution(status, output_target.get("object"), output_target.get("record_id"),
                      str(output_target.get("revision")) if output_target.get("revision") is not None else None,
                      tuple(provisional) if status == Status.RESOLVED else (),
                      tuple(dict.fromkeys(queries)), tuple(dict.fromkeys(issues)))


def main() -> None:
    parser = argparse.ArgumentParser(description="Check a normalized Salesforce price-evidence snapshot")
    parser.add_argument("snapshot", type=Path)
    parser.add_argument("--fixture-mode", action="store_true",
                        help="validate saved dmuat subset fixtures only; never use for production claims")
    args = parser.parse_args()
    snapshot = json.loads(args.snapshot.read_text(encoding="utf-8"))
    print(json.dumps(resolve_price(snapshot, fixture_mode=args.fixture_mode).to_dict(), indent=2))


if __name__ == "__main__":
    main()
