# L2C price field-resolution guard

`guard.py` is a read-only, agent-neutral decision gate for a normalized Salesforce evidence snapshot. It cannot access or configure the company's external agent. The integration point is **before every price claim**, including a price volunteered in a transaction summary.

## Integration contract

1. Query Salesforce with the exact supplied number or record ID. Record every exact match, its actual object, record ID, revision, and verified links. If only a Quote matches a number called an Order, identify the actual Quote and flag the mismatch. If both Quote and Order match, select the requested object only after checking their exact link and revision.
2. Obtain full sObject Describe and Tooling `CustomField.Metadata` for the target and line objects. The adapter must create the discovery manifest from those tool outputs, including the pricing candidate inventory and API names. Query **every discovered candidate** on the exact target record/revision and record `zero`, `value`, `null`, `unqueried`, `inaccessible`, `omitted`, or `missing`. Do not build the manifest from a default record response or from familiar standard fields.
3. Include field API name, label, description, help text, data type, formula, rollup source/filter, and relationship. A primary mapping needs specific SharePoint field-mapping evidence **or** Salesforce metadata plus transaction pricing evidence. Rollups require their source and filter definition. `net` or `gross` additionally requires explicit basis-definition evidence. `as_recorded` reports an exact configured field/rollup scope without claiming net or gross.
4. Include target `CurrencyIsoCode` provenance and raw, unconverted field values with each value's currency. Supply each line's parent/revision, quantity, eligibility, bundle treatment, and rate-versus-extended meaning. The line set also needs trusted `count_evidence` from the Salesforce query response: `totalSize`, complete pagination, exact parent filter, and distinct returned row IDs. The guard checks these against the supplied lines and requires source-line reconciliation for a rollup; a verified empty eligible source can establish a real zero. Quantity zero is a fact, not an automatic exclusion rule. A SOQL currency aggregate is never treated as a record-currency amount.
5. Call `resolve_price(snapshot)`. On `needs_query`, execute the named **read-only** Salesforce queries and retry without asking the business user whether to fetch lines. On `ambiguous`, report the narrow verified facts and the unresolved scope briefly; consult SharePoint for process or policy meaning. Only `resolved` contains reportable amounts, and only for the explicitly requested measures.

The JSON fixtures show the input shape and normalize the known relevant fields in the saved dmuat investigation. They explicitly declare `known_relevant_dmuat_subset`, and the production default returns `needs_query` for them. `--fixture-mode` runs only local validation against that subset. The guard validates the presence and consistency of a supplied inventory, but cannot independently prove that a production `full_sobject_describe_plus_customfield_metadata` declaration is true or authenticate free-text evidence. A trusted backend adapter must generate the inventory and references directly from actual complete Salesforce Describe/CustomField results, never from model-authored or manually selected fields, and retain source results for audit. Until connected to the external agent, this is a tested integration handoff, not a live-agent fix.

A separate [read-only dmuat inventory](../investigations/20261011-l2c-field-resolution/inventory/README.md) captures full Describe results and value states for all exposed numeric fields on the two example transactions. It helps the external-agent team build the trusted adapter; it is not a universal pricing map.

## Current dmuat examples

- `fixtures/order-dmuat.json` is normalized from `investigations/20261011-l2c-field-resolution/order/order-evidence.json` and the Order metadata findings. The same business number matches Quote and Order. The exact Order's root-line cumulative rollup resolves to CAD 9,451.37 MRC and CAD 0 NRC **as recorded**. All five line quantities are zero. The overage line's 0.65 is a rate-like value with zero `TotalPrice`, `NetTotalPrice`, and cumulative MRC; it is not added to the root-line total.
- `fixtures/quote-dmuat.json` is normalized from `investigations/20261011-l2c-field-resolution/quote/quote-evidence.json`. The Quote's configured root-line rollups are PHP 0 MRC and PHP 37,754 NRC **as recorded**. Its standard `GrandTotal` is PHP 99,784, and two child lines have nonzero prices. A generic `total_price` request returns `ambiguous`; neither an overall zero price nor a net/gross basis has been established.

These fixtures are transaction-specific evidence, not universal API mappings or production rules. Salesforce field mappings can differ by object, product, revision, and org.

The Order's raw `Total_MRC__c` is `9451.3699995698`; the fixture reports 9,451.37 using the read-only `CurrencyType.DecimalPlaces=2` result for CAD. The field's own Describe scale is 4, so the currency display scale is supplied separately with provenance. The same read-only CurrencyType check found 2 decimal places for PHP.

## Run locally

Use Python 3.10 or newer:

```powershell
python l2c-field-resolution/build_fixtures.py
python -m unittest discover -s l2c-field-resolution -p 'test_*.py' -v
python l2c-field-resolution/guard.py l2c-field-resolution/fixtures/order-dmuat.json --fixture-mode
```

The module performs no Salesforce writes, incident creation, workflow triggers, or messaging. It does not replace SharePoint evidence for approvals, process transitions, or remedies.
