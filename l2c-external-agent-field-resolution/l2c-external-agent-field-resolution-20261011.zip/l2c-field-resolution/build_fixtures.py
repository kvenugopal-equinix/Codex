"""Normalize saved, read-only dmuat evidence. No Salesforce connection."""

from __future__ import annotations

import json
from decimal import Decimal
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "investigations" / "20261011-l2c-field-resolution"
OUT = Path(__file__).resolve().parent / "fixtures"


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)


def md(api: str, label: str, kind: str = "Currency", description: str = "", rollup: str = "") -> dict[str, str]:
    return {"api_name": api, "label": label, "data_type": kind, "description": description,
            "help_text": "", "formula": "", "rollup": rollup, "relationship": ""}


def ev(metadata: str, transaction: str, rollup: str = "") -> list[dict[str, str]]:
    result = [{"source": "salesforce_metadata", "detail": metadata},
              {"source": "transaction_pricing", "detail": transaction}]
    if rollup:
        result.append({"source": "rollup_definition", "detail": rollup})
    return result


def field(record: str, revision: str, metadata: dict[str, str], value: Any, currency: str,
          measures: list[str], measure: str, role: str, meaning: str, evidence: list[dict[str, str]],
          kind: str | None = None) -> dict[str, Any]:
    state = "null" if value is None else "zero" if Decimal(str(value)) == 0 else "value"
    mapping: dict[str, Any] = {"measure": measure, "role": role, "meaning": meaning, "evidence": evidence}
    if kind:
        mapping.update(amount_kind=kind, basis="as_recorded")
    return {"record_id": record, "revision": revision, "metadata": metadata,
            "observed": {"state": state, "amount": None if value is None else str(value),
                         "currency": currency, "source": "raw_field",
                         "currency_provenance": "unconverted_record"},
            "potential_measures": measures, "mapping": mapping}


def base(identifier: str, obj: str, record: str, revision: str, currency: str,
         matches: list[dict[str, Any]], links: list[dict[str, Any]], provenance: str) -> dict[str, Any]:
    return {"provenance": provenance, "fixture_attestation": "known_relevant_dmuat_subset",
            "request": {"identifier": identifier, "target_object": obj, "revision": revision,
                        "measures": ["mrc", "nrc"]},
            "lookup": {"queried": True, "identifier": identifier, "matches": matches},
            "target": {"object": obj, "record_id": record, "revision": revision,
                       "revision_evidence": "Exact transaction revision checked against linked Quote.Revision__c"},
            "links_checked": True, "links": links,
            "record_currency": currency,
            "currency_evidence": {"record_id": record, "revision": revision,
                                  "field_api_name": "CurrencyIsoCode", "source": "raw_field",
                                  "currency": currency}}


def manifests(result: dict[str, Any], obj: str, line_obj: str, header: list[dict[str, Any]],
              line_names: list[str]) -> None:
    target = result["target"]
    result["discovery"] = {
        "header": {"complete": True, "source": "saved_read_only_investigation_subset",
                   "object": obj, "record_id": target["record_id"], "revision": target["revision"],
                   "candidate_api_names": [c["metadata"]["api_name"] for c in header],
                   "inventory_source": "known_relevant_dmuat_subset",
                   "inventory_field_count": len(header),
                   "inventory_pricing_fields": [c["metadata"] for c in header]},
        "line": {"complete": True, "source": "saved_read_only_investigation_subset",
                 "object": line_obj, "candidate_api_names": line_names,
                 "inventory_source": "known_relevant_dmuat_subset",
                 "inventory_field_count": len(line_names),
                 "inventory_pricing_fields": [c["metadata"] for c in result["line_set"]["lines"][0]["candidates"]]}}


def order_fixture() -> dict[str, Any]:
    path = EVIDENCE / "order" / "order-evidence.json"
    e = load(path)
    order, quote = e["order"], e["quote"]
    oid, qid, rev = order["id"], quote["id"], str(quote["revision"])
    source = str(path.relative_to(ROOT))
    matches = [{"object": "Order", "record_id": oid, "revision": rev, "exact_match": True,
                "matched_field": "Order_Number__c"},
               {"object": "Quote", "record_id": qid, "revision": rev, "exact_match": True,
                "matched_field": "Quote_Number__c"}]
    links = [{"from_object": "Quote", "from_record_id": qid, "from_revision": rev,
              "to_object": "Order", "to_record_id": oid, "to_revision": rev,
              "relationship": "Order.QuoteId", "verified": True}]
    result = base(e["businessNumber"], "Order", oid, rev, "CAD", matches, links, source)
    result["currency_scale"] = e["currency"]["cadDecimalPlaces"]
    result["currency_scale_evidence"] = {"source": "salesforce_currency_metadata",
                                         "detail": source + " currency.cadDecimalPlaces from read-only CurrencyType"}
    mroll = "SUM OrderItem.Cumulative_MRC__c via OrderItem.OrderId; Root_Line__c=true; exclude Pending Cancellation/Canceled"
    nroll = "SUM OrderItem.Cumulative_NRC__c via OrderItem.OrderId; Root_Line__c=true; exclude Pending Cancellation/Canceled"
    metadata = "order/metadata/unpackaged/unpackaged/objects/Order.object"
    header = [
        field(oid, rev, md("Total_MRC__c", "Total MRC", "Summary", "Order root cumulative MRC", mroll),
              order["totalMrcRollup"], "CAD", ["mrc", "total_price"], "mrc", "primary",
              "Order root-line cumulative MRC rollup as recorded", ev(metadata, source, mroll), "document_total"),
        field(oid, rev, md("Total_NRC__c", "Total NRC", "Summary", "Order root cumulative NRC", nroll),
              order["totalNrcRollup"], "CAD", ["nrc", "total_price"], "nrc", "primary",
              "Order root-line cumulative NRC rollup as recorded", ev(metadata, source, nroll), "document_total"),
        field(oid, rev, md("Total_Recurring_Charges__c", "Total MRC"),
              order["otherTotalRecurringCharges"], "CAD", ["mrc"], "mrc", "context_only",
              "Duplicate label; plain currency default has no verified business total meaning",
              ev("order/metadata3/Order.object", source)),
        field(oid, rev, md("Total_One_Time_charges__c", "Total NRC"),
              order["otherTotalOneTimeCharges"], "CAD", ["nrc"], "nrc", "context_only",
              "Duplicate label; plain nullable currency is not the configured rollup",
              ev("order/metadata3/Order.object", source)),
        field(oid, rev, md("TotalAmount", "Total Amount"), order["totalAmount"], "CAD",
              ["total_price"], "total_price", "context_only",
              "Standard amount coincides here but does not define MRC/NRC scope",
              ev("Order.TotalAmount metadata", source)),
    ]
    result["header_candidates"] = header
    lines = []
    for raw in e["orderLines"]:
        lid = raw["id"]
        included = raw["rootLine"] and raw["status"] not in ("Pending Cancellation", "Canceled")
        candidates = [
            field(lid, rev, md("Cumulative_MRC__c", "Cumulative MRC"), raw["cumulativeMrc"], "CAD",
                  ["mrc"], "mrc", "primary", "Eligible root-line cumulative MRC",
                  ev("OrderItem.Cumulative_MRC__c metadata", source, mroll), "extended_charge"),
            field(lid, rev, md("Cumulative_NRC__c", "Cumulative NRC"), raw["cumulativeNrc"], "CAD",
                  ["nrc"], "nrc", "primary", "Eligible root-line cumulative NRC",
                  ev("OrderItem.Cumulative_NRC__c metadata", source, nroll), "extended_charge"),
            field(lid, rev, md("MRC__c", "MRC"), raw["mrc"], "CAD", ["mrc"], "mrc", "context_only",
                  "Plain line MRC may represent a rate; overage is 0.65 with zero extended charge",
                  ev("OrderItem.MRC__c metadata", source)),
            field(lid, rev, md("NRC__c", "NRC"), raw["nrc"], "CAD", ["nrc"], "nrc", "context_only",
                  "Plain nullable line NRC is distinct from cumulative root-line NRC",
                  ev("OrderItem.NRC__c metadata", source)),
            field(lid, rev, md("NetUnitPrice", "Net Unit Price"), raw["netUnitPrice"], "CAD",
                  ["total_price"], "total_price", "context_only",
                  "Unit/rate field; overage is 0.65 but extended NetTotalPrice is zero",
                  ev("OrderItem.NetUnitPrice metadata", source)),
            field(lid, rev, md("NetTotalPrice", "Net Total Price"), raw["netTotalPrice"], "CAD",
                  ["total_price"], "total_price", "context_only",
                  "Extended net line price is separate from cumulative root-line MRC/NRC",
                  ev("OrderItem.NetTotalPrice metadata", source)),
            field(lid, rev, md("TotalPrice", "Total Price"), raw["totalPrice"], "CAD",
                  ["total_price"], "total_price", "context_only",
                  "Extended line price; overage is zero despite its 0.65 rate",
                  ev("OrderItem.TotalPrice metadata", source)),
        ]
        lines.append({"record_id": lid, "parent_record_id": oid, "revision": rev,
                      "quantity": str(raw["quantity"]),
                      "inclusion": {m: "include" if included else "exclude" for m in ("mrc", "nrc")},
                      "inclusion_evidence": "Verified root/status rollup filter on queried line",
                      "bundle_treatment": "parent_amount" if included else "excluded_component",
                      "bundle_group": lid if included else raw["parentOrderItemId"],
                      "candidates": candidates})
    result["line_set"] = {"object": "OrderItem", "queried": True, "complete": True,
                          "expected_count": len(lines), "lines": lines,
                          "count_evidence": {"source": "salesforce_query_totalSize", "object": "OrderItem",
                                             "parent_record_id": oid, "revision": rev,
                                             "parent_lookup_field": "OrderId", "total_size": len(lines),
                                             "pages_complete": True,
                                             "record_ids": [line["record_id"] for line in lines]}}
    manifests(result, "Order", "OrderItem", header,
              ["Cumulative_MRC__c", "Cumulative_NRC__c", "MRC__c", "NRC__c",
               "NetUnitPrice", "NetTotalPrice", "TotalPrice"])
    return result


def quote_fixture() -> dict[str, Any]:
    path = EVIDENCE / "quote" / "quote-evidence.json"
    e = load(path)
    quote = e["identity"]
    qid, rev, currency = quote["id"], str(quote["Revision__c"]), quote["CurrencyIsoCode"]
    source = str(path.relative_to(ROOT))
    result = base(quote["Quote_Number__c"], "Quote", qid, rev, currency,
                  [{"object": "Quote", "record_id": qid, "revision": rev,
                    "exact_match": True, "matched_field": "Quote_Number__c"}], [], source)
    result["currency_scale"] = e["currencyType"]["decimalPlaces"]
    result["currency_scale_evidence"] = {"source": "salesforce_currency_metadata",
                                         "detail": source + " currencyType.decimalPlaces from read-only CurrencyType"}
    result["target"]["revision_evidence"] = "Quote.Revision__c=1 on exact queried Quote"
    mroll = "SUM QuoteLineItem.Cumulative_MRC__c via QuoteLineItem.QuoteId where Root_Line__c=true"
    nroll = "SUM QuoteLineItem.Cumulative_NRC__c via QuoteLineItem.QuoteId where Root_Line__c=true"
    header = []
    for api, measure, rollup in (("Total_MRC__c", "mrc", mroll),
                                 ("Total_NRC__c", "nrc", nroll)):
        header.append(field(qid, rev, md(api, "Total " + measure.upper(), "Summary",
                           e["verifiedRollups"][api]["metadataDescription"], rollup),
                            e["headerPricing"][api], currency, [measure, "total_price"], measure,
                            "primary", f"Quote root-line cumulative {measure.upper()} rollup as recorded",
                            ev(source + " verifiedRollups", source + " header and line values", rollup),
                            "document_total"))
    for api, measure in (("TotalMRC__c", "mrc"), ("TotalNRC__c", "nrc")):
        header.append(field(qid, rev, md(api, "Total " + measure.upper() + " NA"),
                            e["headerPricing"][api], currency, [measure], measure, "context_only",
                            "Separate nullable field; label does not establish a business total",
                            ev(source + " otherFieldMetadata", source + " null value")))
    for api in ("Subtotal", "TotalPrice", "GrandTotal"):
        header.append(field(qid, rev, md(api, api), e["headerPricing"][api], currency,
                            ["total_price"], "total_price", "context_only",
                            "Standard price field differs from configured root-line MRC/NRC rollups",
                            ev(source + " otherFieldMetadata", source + " line reconciliation")))
    for api in ("Discount", "AppliedDiscount", "AppliedDiscountAmount", "TotalPriceOverride",
                "Tax", "ShippingHandling"):
        header.append(field(qid, rev, md(api, api), e["headerPricing"][api], currency,
                            ["total_price"], "total_price", "context_only",
                            "Discount, override, tax, or shipping context; no verified overall-price mapping",
                            ev(source + " header field metadata", source + " explicit zero/null values")))
    result["header_candidates"] = header
    lines = []
    for raw in e["lineSummary"]:
        lid = raw["id"]
        included = raw["root"]
        candidates = []
        for api, measure, rollup in (("Cumulative_MRC__c", "mrc", mroll),
                                     ("Cumulative_NRC__c", "nrc", nroll)):
            candidates.append(field(lid, rev, md(api, api), raw[api], currency, [measure], measure,
                                    "primary", f"Eligible root-line cumulative {measure.upper()}",
                                    ev(source + " line metadata", source + " line values", rollup),
                                    "extended_charge"))
        for api, measure in (("MRC__c", "mrc"), ("NRC__c", "nrc"),
                             ("ChargesNRC__c", "nrc"), ("TotalPrice", "total_price"),
                             ("NetTotalPrice", "total_price"), ("NetUnitPrice", "total_price")):
            extra = field(lid, rev, md(api, api), raw.get(api), currency, [measure], measure,
                          "context_only", "Additional line pricing field; not the configured root-line rollup source",
                          ev(source + " line metadata", source + " explicit line value state"))
            if api not in raw:
                extra["observed"]["state"] = "omitted"
            candidates.append(extra)
        lines.append({"record_id": lid, "parent_record_id": qid, "revision": rev,
                      "quantity": str(raw["quantity"]),
                      "inclusion": {m: "include" if included else "exclude" for m in ("mrc", "nrc")},
                      "inclusion_evidence": "Verified Root_Line__c=true rollup filter on queried line",
                      "bundle_treatment": "parent_amount" if included else "excluded_component",
                      "bundle_group": lid if included else raw["parentId"],
                      "candidates": candidates})
    result["line_set"] = {"object": "QuoteLineItem", "queried": True, "complete": True,
                          "expected_count": len(lines), "lines": lines,
                          "count_evidence": {"source": "salesforce_query_totalSize", "object": "QuoteLineItem",
                                             "parent_record_id": qid, "revision": rev,
                                             "parent_lookup_field": "QuoteId", "total_size": len(lines),
                                             "pages_complete": True,
                                             "record_ids": [line["record_id"] for line in lines]}}
    manifests(result, "Quote", "QuoteLineItem", header,
              ["Cumulative_MRC__c", "Cumulative_NRC__c", "MRC__c", "NRC__c",
               "ChargesNRC__c", "TotalPrice", "NetTotalPrice", "NetUnitPrice"])
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for name, fixture in (("order-dmuat.json", order_fixture()),
                          ("quote-dmuat.json", quote_fixture())):
        output = OUT / name
        output.write_text(json.dumps(fixture, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(output)


if __name__ == "__main__":
    main()
