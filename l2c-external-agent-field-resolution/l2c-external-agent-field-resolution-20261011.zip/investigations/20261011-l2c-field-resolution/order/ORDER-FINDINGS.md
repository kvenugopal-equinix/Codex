# dmuat field-resolution evidence: 1-26LRL9028

Read-only Salesforce inspection on 2026-10-11, using alias `dmuat`. These findings describe the current sandbox records and metadata; they do not establish a universal rule for every transaction.

## Exact target and revision

- `Order.Order_Number__c = 1-26LRL9028` resolves to Order `801Qh00000lzr5yIAA`, standard Order Number `00000247`, name `DMCL_Server Increase`, Type `Change Order`, Status `Closed`, CurrencyIsoCode `CAD`.
- This Order's `QuoteId = 0Q0Qh0000064wtCKAQ`. The linked Quote also has `Quote_Number__c = 1-26LRL9028`, `Revision__c = 1`, CurrencyIsoCode `CAD`, and Status `Order Created`. The business number therefore identifies both linked objects; the question's requested object matters.

## Metadata resolution

- `Order.Total_MRC__c` (label `Total MRC`) is a Summary field. Its description says it displays the Order's total MRC by fetching cumulative MRC from root Order lines. It sums `OrderItem.Cumulative_MRC__c` where `OrderItem.Root_Line__c = True` and Status is neither `Pending Cancellation` nor `Canceled`.
- `Order.Total_NRC__c` (label `Total NRC`) similarly sums `OrderItem.Cumulative_NRC__c` over those root lines. Its description incorrectly says “Quote,” but the summarized field and foreign key are `OrderItem` and `OrderItem.OrderId`.
- Distinct Order fields share these labels: `Total_Recurring_Charges__c` is also labeled `Total MRC` and is a plain Currency field with default 0; `Total_One_Time_charges__c` is also labeled `Total NRC` and is a plain Currency field. For this record, they hold 0 and null, respectively. Labels alone cannot choose the right field.
- `OrderItem.MRC__c` and `NRC__c` are plain Currency fields without descriptions. The `Price_Type__c` formula marks a Term-Defined selling model as `Recurring`; it does not by itself say that every `MRC__c` value is an extended charge.
- `OrderItem.Root_Line__c` is a writable checkbox whose description refers to an offering element for the Billing API. It is distinct from calculated `Root_Line_Flag__c`, which tests for an empty `ParentOrderItemId`.

## Record values and line reconciliation

| Item | Product | Root line | MRC__c | Cumulative_MRC__c | NetUnitPrice | TotalPrice |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 0000000572 | Virtual Data Center | false | 644.96 | 644.96 | 644.96 | 644.96 |
| 0000000573 | Virtual Data Center Product | true | 0 | 644.96 | 0 | 0 |
| 0000000574 | Managed Backup Product | true | 0 | 8806.4099995698 | 0 | 0 |
| 0000000575 | Managed Backup - Volume | false | 8806.4099995698 | 8806.4099995698 | 0.19530738522 | 8806.4099995698 |
| 0000000576 | Backup - Overage Charges | false | 0.65 | 0 | 0.65 | 0 |

All five OrderItems have CurrencyIsoCode `CAD` and Status `Closed`. All have Quantity 0, so quantity alone does not determine extended amount in this data. The two root lines' cumulative MRC values total `9451.3699995698`, displayed as **CAD 9,451.37**. `Order.Total_MRC__c` and `Order.TotalAmount` each equal that value. `Order.Total_NRC__c` is an actual queried **0**, while `Order.Total_One_Time_charges__c` is **null**.

The overage line's `MRC__c = 0.65` equals its `NetUnitPrice`, while `TotalPrice`, `NetTotalPrice`, and `Cumulative_MRC__c` are 0. It has `Quantity = 0`, no Quantity Unit of Measure, no Aggregated Quantity, and a `Term Based - Monthly` Product Selling Model. Its name and these values support treating 0.65 as a unit/usage rate with no current extended charge. The `MRC__c` metadata does not itself prove that interpretation for every line. Naively summing all five `MRC__c` values produces about 9452.02 and incorrectly includes the 0.65.

`CurrencyType.DecimalPlaces` is 2 for CAD. The custom `Order.Total_MRC__c` field's Describe scale is 4, so its raw queried value retains more fractional digits; CAD 9,451.37 is the two-decimal currency presentation of that verified rollup, not a claim that the field's schema scale is 2.

## Currency aggregate reproduction

`CurrencyType` reports USD as the corporate currency (`IsCorporate = true`, ConversionRate 1) and CAD as noncorporate (ConversionRate 1.3919). An actual SOQL `SUM(OrderItem.MRC__c)` over these five lines returned **6790.73** in corporate USD, exactly the earlier agent figure that was mislabeled CAD. An aggregate over the eligible root-line `Cumulative_MRC__c` values returned 6790.27 corporate USD. These aggregate results must not be labeled with the Order's CAD currency. Directly queried, unconverted record fields and line values above are CAD.

## Evidence files

- `metadata/unpackaged/unpackaged/objects/Order.object`: exact rollup definitions.
- `metadata/unpackaged/unpackaged/objects/OrderItem.object`: `MRC__c`, `NRC__c`, and `Price_Type__c` definitions.
- `metadata2/unpackaged/unpackaged/objects/OrderItem.object`: cumulative and root-line field definitions.
- `metadata3/unpackaged/unpackaged/objects/Order.object`: duplicate-label plain Currency fields.
