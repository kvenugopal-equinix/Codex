# L2C field resolution: `dmuat` evidence and integration handoff

Read-only investigation on 2026-10-11. The company L2C agent is external to this workspace. Its current configuration, action traces, and two Library files were not accessible here, so no live-agent or Library change has been made.

The unavailable files are behavior Library ID `libfile_395797c98e1081918485f5c00b79ae92` (latest reported version 5) and navigation KB Library ID `libfile_1c3201b730e08191a366a37317877ebe` (latest reported version 1). Their prior `/workspace/scratch/...` paths do not exist in this workspace. Read those exact current versions before replacing either artifact.

## What the failures establish

- In the supplied Quote screenshot, the agent identified dedicated pricing fields but answered from `GrandTotal` before retrieving their values. That is a missing execution gate. The screenshot does not show whether its Salesforce tool omitted fields or the model skipped a follow-up query; an action trace is needed to distinguish those causes.
- In `dmuat`, Order fields have duplicate business labels. `Total_MRC__c` and `Total_Recurring_Charges__c` are both labeled “Total MRC” but have different definitions and values. Neither API name familiarity nor label matching is a safe selector.
- The Order's bad 6,790.73 figure is reproducible with a currency `SUM()` over the wrong line field: the aggregate is in corporate USD, while the Order is CAD. [Salesforce documents that currency aggregates default to the system currency](https://developer.salesforce.com/docs/platform/salesforce-soql-sosl/guide/sforce-api-calls-soql-select-agg-functions-field-types.html).

The independent [full Describe and numeric value-state inventory](inventory/README.md) covers the four relevant objects and the exact example records. It shows that the conflicting standard and custom values coexist in Salesforce, including genuine zeros and nulls. Candidate discovery in that inventory is deliberately broad; business meaning still requires the metadata and transaction checks below.

## Example 1: `1-26LRL9028`

The number identifies both a Quote (revision 1) and its linked Order `00000247`. The requested Order is CAD. Its `Total_MRC__c` is a rollup of `OrderItem.Cumulative_MRC__c` on root lines that are not Pending Cancellation or Canceled. That rollup is **CAD 9,451.37**; the corresponding `Total_NRC__c` is an actual queried **CAD 0**. This mapping is supported by CustomField metadata and the exact Order lines, rather than by the field names alone.

The overage child line contains `MRC__c = 0.65` and `NetUnitPrice = 0.65`, while its `TotalPrice`, `NetTotalPrice`, and `Cumulative_MRC__c` are zero. Adding 0.65 to the Order's extended MRC inflates the result to 9,452.02. All five Order lines have quantity zero, including charged lines, so quantity zero by itself is not a general exclusion rule. The authoritative rollup definition supplies the eligibility rule for this record. See [ORDER-FINDINGS.md](order/ORDER-FINDINGS.md) for the line and metadata evidence.

## Example 2: `1-26LXC1476`

The exact record is Quote `00198768`, revision 1, Draft, PHP; no Order is linked to that Quote in `dmuat`. Its queried `Total_MRC__c` is a genuine **PHP 0** and `Total_NRC__c` is **PHP 37,754**. Both are root-line rollups. `Subtotal` is also a queried numeric zero, not an omitted value. Three root Quote lines have cumulative MRC values of zero, while one contributes 37,754 NRC. Separately, two child Power/Space lines each have 49,892 in line MRC and `TotalPrice`, producing the generic **PHP 99,784 `GrandTotal`**. A child Space line also has 696,000 cumulative NRC that the root-only rollup excludes. The generic total and dedicated rollups represent different aggregations in the current data. This evidence supports reporting MRC zero, but it does **not** prove that the Quote's overall price is zero or that excluding the child charges is intended. The agent should explain the discrepancy briefly and ask which basis matters only if the user's question requires one total. See [QUOTE-FINDINGS.md](quote/QUOTE-FINDINGS.md) for the field and line evidence.

## Mechanism to integrate into the company agent

Expose one read-only Salesforce field-resolution action and make it a required predecessor to every amount-bearing answer, including a volunteered summary. The trusted action, not the language model, must assemble the metadata, mappings, and record snapshot. It should return a typed result (`resolved`, `needs_query`, or `ambiguous`) rather than raw rows for the language model to interpret. A local, agent-neutral guard and fixtures are in [`l2c-field-resolution`](../../l2c-field-resolution/).

```mermaid
flowchart LR
  A[Transaction number or ID] --> B[Exact Quote and Order lookup]
  B --> C[Metadata, candidate values, linked lines]
  C --> D[Deterministic price guard]
  D -->|resolved| E[Brief factual answer]
  D -->|needs_query| C
  D -->|ambiguous| F[State verified measures and clarify basis]
```

1. Resolve an exact ID or business number against candidate objects before choosing one. Return exact record ID, object, revision, and linked record IDs. A business number may identify both Quote and Order.
2. Discover numeric pricing candidates across standard and custom fields from Salesforce Describe; obtain admin descriptions and rollup definitions from field metadata where available. Read their actual values and relevant parent/child lines explicitly. [Describe supplies fields and relationships](https://developer.salesforce.com/docs/platform/api-rest/guide/resources-sobject-describe.html). A metadata name or label is a candidate, not proof of business meaning.
3. Preserve a separate state for `zero`, `value`, `null`, `unqueried`, and `inaccessible` for every relevant candidate. A found but unfetched custom field must produce `needs_query`, not a generic-total fallback. Field-level access failures must not masquerade as nulls.
4. Select a measure only when its formula or rollup, currency, price basis, line eligibility, bundle treatment, and transaction values support the mapping. Compute any necessary sum from unconverted row values with decimal arithmetic in a verified common currency. Do not add a unit or usage rate as an extended charge. A populated standard total and a zero custom total may coexist with different meanings.
5. Use SharePoint for process and policy rules. Missing SharePoint field mappings alone do not invalidate a factual Salesforce mapping supported by metadata and transaction evidence. If the price basis remains genuinely ambiguous, return the facts and the unresolved distinction without guessing.

The deterministic gate belongs in the company agent's action workflow. A `needs_query` result should trigger the required read-only Salesforce calls automatically; it is not a question asking the business user whether to fetch lines. If its runtime only offers optional model-selected queries, add a wrapper action that performs these reads and checks before it returns an answerable result. The current Library instructions and navigation KB should be edited only after their latest versions are supplied and reviewed. Live verification requires the external agent's Salesforce action list and at least one trace showing action inputs and outputs for each failure example.

## Other behavior to preserve during integration

For simple value questions, keep the read scope to the requested price evidence. For troubleshooting, traverse the applicable Opportunity/solution, Quote/pricing/terms, approval/agreement, Order, orchestration, fulfillment, asset, and billing branches using exact linked records and timestamps. An existing Order linked to the exact Quote and revision proves that Order creation occurred; a later OSM error must be tied to its actual operation and stage. A “Change Order” label does not by itself establish that an amount is only a delta. Use SharePoint for process rules and documented remedies, and treat a production change as confirmed only with deployment evidence. Keep replies brief, omit raw queries and Jira numbers unless requested, and do not expand an unfamiliar abbreviation by guesswork.

This integration is read-only. Incident creation remains a separate explicit-request workflow that must show a draft short description and details and receive a clear yes before creation. It must not ask for impact, urgency, priority, or assignment group. No other record updates, replay, messaging, or monitoring belong in the field-resolution path.
