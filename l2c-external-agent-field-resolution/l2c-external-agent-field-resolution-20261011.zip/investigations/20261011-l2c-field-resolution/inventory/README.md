# dmuat field inventory for the two L2C examples

Read-only capture on 2026-10-11 with Salesforce CLI and explicit `--target-org dmuat --json`. Full sObject Describe responses are saved as `Order.describe.json`, `OrderItem.describe.json`, `Quote.describe.json`, and `QuoteLineItem.describe.json`. `pricing-value-states.json` contains selected transaction value states, without raw `FIELDS(ALL)` rows or unrelated text/PII. `collect-value-states.ps1` reproduces the value-state capture.

| Object | Describe fields | Numeric fields explicitly queried | Currency fields queried | Pricing candidate numeric fields | Exact records |
| --- | ---: | ---: | ---: | ---: | ---: |
| Order | 215 | 49 | 22 | 25 | 1 |
| OrderItem | 298 | 61 | 36 | 51 | 5 |
| Quote | 221 | 42 | 15 | 20 | 1 |
| QuoteLineItem | 183 | 51 | 22 | 37 | 5 |
| **Total** | **917** | **203** | **95** | **133** | **12** |

The exact filters were Order `801Qh00000lzr5yIAA` and its five OrderItems for business number `1-26LRL9028`, plus Quote `0Q0Ek00000B79jOKAR` and its five QuoteLineItems for `1-26LXC1476`. Each query selected every `currency`, `double`, `int`, and `percent` field exposed by Describe, plus `Id` and `CurrencyIsoCode`. All expected records returned. None of the selected numeric fields was omitted from a returned row. This confirms **value states for every accessible currency field** on these records; it does not claim access to fields absent from this user's Describe response.

Every currency field is a candidate, regardless of name. Noncurrency numeric candidates use a case-insensitive match of API name, label, or inline help text against pricing, quantity, freight, or shipping-charge terms: `mrc|nrc|price|charg|rate|cost|amount|discount|total|quantity|tax|fee|margin|usage|subtotal|adjustment|freight|shipping[_ ]*(handling|cost|amount|charge|rate|fee|price)`. This is a broad discovery filter, **not** a verified business mapping; geolocation fields such as `ShippingLatitude` are excluded. For candidate numeric fields, the JSON stores exact returned amounts and distinguishes `zero`, `null`, `nonzero`, and `omitted`. For noncandidate numeric fields it stores only the state. In particular, Quote `ShippingHandling` is included as a currency candidate and is null on the investigated record.

The capture confirms the key conflicting values:

- Order `Total_MRC__c = 9451.3699995698` and `Total_NRC__c = 0` in CAD. The separate plain Currency field `Total_Recurring_Charges__c` is also labeled “Total MRC” but holds 0; `Total_One_Time_charges__c`, also labeled “Total NRC,” is null. `OrderItem.MRC__c` includes a 0.65 CAD overage-line amount while that line's `TotalPrice` and `Cumulative_MRC__c` are both 0.
- Quote `Total_MRC__c = 0`, `Total_NRC__c = 37754`, `Subtotal = 0`, and `TotalPrice = GrandTotal = 99784` in PHP. The two child lines each have `MRC__c = 49892` and `TotalPrice = 49892`, while the root-line MRC rollup is zero. All five `QuoteLineItem.NRC__c` values are **null**, including lines with nonzero `ChargesNRC__c` or `Cumulative_NRC__c`.

The full Describe files include labels, data types, calculated flags/formulas where returned, and relationship metadata. They do not by themselves provide all custom-field descriptions or the complete rollup filter definitions; the companion order and quote investigations use retrieved CustomField metadata for that. This inventory reads numeric values only, so it does not independently revalidate revisions, product names, root flags, statuses, or process rules. It is a snapshot of these two transactions, not a universal pricing-field map or proof that a calculated price reflects completed pricing.
