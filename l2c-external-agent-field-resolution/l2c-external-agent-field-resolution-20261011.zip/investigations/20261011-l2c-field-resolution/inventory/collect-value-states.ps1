Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$workspace = (Resolve-Path (Join-Path $root '../../..')).Path
$env:Path = "$(Join-Path $workspace '.tools/node-v24.18.0-win-x64');$env:Path"
$sf = Join-Path $workspace '.tools/sf-prefix/node_modules/.bin/sf.cmd'

$targets = @(
    @{ Object = 'Order'; Where = "Id = '801Qh00000lzr5yIAA'"; Expected = 1 },
    @{ Object = 'OrderItem'; Where = "OrderId = '801Qh00000lzr5yIAA'"; Expected = 5 },
    @{ Object = 'Quote'; Where = "Id = '0Q0Ek00000B79jOKAR'"; Expected = 1 },
    @{ Object = 'QuoteLineItem'; Where = "QuoteId = '0Q0Ek00000B79jOKAR'"; Expected = 5 }
)

# Candidate values are retained only for pricing, quantity, and charge fields. All
# other numeric fields retain a null/zero/nonzero state, without their amount.
$pricingPattern = '(?i)(mrc|nrc|price|charg|rate|cost|amount|discount|total|quantity|tax|fee|margin|usage|subtotal|adjustment|freight|shipping[_ ]*(handling|cost|amount|charge|rate|fee|price))'
$out = [ordered]@{
    source = [ordered]@{
        orgAlias = 'dmuat'
        collectedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
        method = 'Explicit SOQL SELECT of every numeric field returned by sObject Describe; raw rows held only in process memory'
        candidateCriterion = 'Every currency field, plus noncurrency numeric fields whose API name, label, or inline help text matches the pricing/quantity/shipping/freight regex'
    }
    objects = [ordered]@{}
}

foreach ($target in $targets) {
    $objectName = $target.Object
    $describe = Get-Content (Join-Path $root "$objectName.describe.json") -Raw | ConvertFrom-Json
    if ($describe.status -ne 0) { throw "Describe failed for $objectName" }
    $fields = @($describe.result.fields | Where-Object { $_.type -in @('currency', 'double', 'int', 'percent') })
    $select = @('Id', 'CurrencyIsoCode') + @($fields | ForEach-Object { $_.name })
    $query = "SELECT $($select -join ', ') FROM $objectName WHERE $($target.Where) ORDER BY Id LIMIT 200"
    $raw = & $sf data query --target-org dmuat --query $query --json
    if ($LASTEXITCODE -ne 0) { throw "SOQL failed for $objectName" }
    $response = $raw | ConvertFrom-Json
    if ($response.status -ne 0) { throw "SOQL status $($response.status) for $objectName" }
    if ($response.result.totalSize -ne $target.Expected) { throw "Unexpected $objectName row count $($response.result.totalSize), expected $($target.Expected)" }

    $fieldMetadata = @($fields | ForEach-Object {
        $candidate = $_.type -eq 'currency' -or (($_.name + ' ' + $_.label + ' ' + $_.inlineHelpText) -match $pricingPattern)
        [ordered]@{
            apiName = $_.name
            label = $_.label
            type = $_.type
            candidate = $candidate
            calculated = $_.calculated
            scale = $_.scale
            precision = $_.precision
        }
    })
    $rows = @($response.result.records | ForEach-Object {
        $record = $_
        $states = [ordered]@{}
        foreach ($field in $fieldMetadata) {
            $name = $field.apiName
            $present = $record.PSObject.Properties.Name -contains $name
            $value = if ($present) { $record.$name } else { $null }
            $state = if (-not $present) { 'omitted' } elseif ($null -eq $value) { 'null' } elseif ([decimal]$value -eq 0) { 'zero' } else { 'nonzero' }
            $entry = [ordered]@{ state = $state }
            if ($field.candidate -and $null -ne $value) { $entry.value = $value }
            $states[$name] = $entry
        }
        [ordered]@{ Id = $record.Id; CurrencyIsoCode = $record.CurrencyIsoCode; numericFields = $states }
    })
    $out.objects[$objectName] = [ordered]@{
        exactFilter = $target.Where
        recordCount = $response.result.totalSize
        totalDescribeFields = @($describe.result.fields).Count
        numericFieldsQueried = $fields.Count
        currencyFieldsQueried = @($fields | Where-Object { $_.type -eq 'currency' }).Count
        pricingCandidateNumericFields = @($fieldMetadata | Where-Object { $_.candidate }).Count
        fieldMetadata = $fieldMetadata
        records = $rows
    }
    Write-Output "$objectName rows=$($rows.Count) numeric=$($fields.Count) currency=$(@($fields | Where-Object { $_.type -eq 'currency' }).Count) candidate=$(@($fieldMetadata | Where-Object { $_.candidate }).Count)"
}

$path = Join-Path $root 'pricing-value-states.json'
$out | ConvertTo-Json -Depth 20 | Set-Content -Path $path -Encoding utf8
Write-Output "Saved $path"
