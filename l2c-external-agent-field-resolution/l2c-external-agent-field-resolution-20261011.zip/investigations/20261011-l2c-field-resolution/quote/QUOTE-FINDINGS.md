# Quote 1-26LXC1476: field-resolution evidence

Read-only investigation in org alias `dmuat` on 2026-10-11. Structured values and relevant metadata are in [quote-evidence.json](quote-evidence.json).

## Exact record and linked scope

- `Quote.Quote_Number__c = 1-26LXC1476` resolves to Quote `0Q0Ek00000B79jOKAR`; standard `QuoteNumber = 00198768`.
- Revision `1`, status `Draft`, quote type `New`, currency `PHP`.
- Linked Opportunity `006Ek00000pWYIxIAO` is also in PHP and has this one Quote in the query result. No Order was returned for `Order.QuoteId = 0Q0Ek00000B79jOKAR`.
- No `MainQuote__c` or `RelatedQuoteId` is populated. The exact custom quote number and revision were checked; there is no observed competing revision on this Opportunity.

## Values and field definitions

| Quote field | Value (PHP) | Metadata meaning |
| --- | ---: | --- |
| `Total_MRC__c` | **0** | Roll-up sum of `QuoteLineItem.Cumulative_MRC__c` where `Root_Line__c = True` |
| `Total_NRC__c` | **37,754** | Roll-up sum of `QuoteLineItem.Cumulative_NRC__c` where `Root_Line__c = True` |
| `TotalMRC__c`, `TotalNRC__c` | **null**, **null** | Separate fields labeled “Total MRC NA” and “Total NRC NA”; unpopulated here |
| `Subtotal` | **0** | Standard calculated currency field; no specific business definition in describe |
| `TotalPrice`, `GrandTotal` | **99,784** each | Standard currency fields; both match the sum of two child line `TotalPrice` values |

Tooling `CustomField.Metadata` explicitly describes `Total_MRC__c` as “To display Total MRC on Quote by fetching the cumulative MRC from Root Quote Lines” and `Total_NRC__c` analogously for NRC. Both have `type = Summary`, `summaryOperation = sum`, `summaryForeignKey = QuoteLineItem.QuoteId`, and the `Root_Line__c = True` filter. These definitions verify what the custom fields compute. They do **not** establish whether the current root-line values fully reflect intended contract pricing.

The Quote header also has `Discount = 0`. `AppliedDiscount`, `AppliedDiscountAmount`, `TotalPriceOverride`, tax, and shipping are null; zero and null are distinct observations. `LastPricedDate` is `2026-09-30T10:38:16Z`, but that timestamp alone does not prove pricing was completed or accepted.

## Line structure and mismatch

All five lines are in PHP and have `skip_price__c = false`:

| Line | Root? | Parent | Cumulative MRC | Cumulative NRC | Line MRC | Charges NRC | TotalPrice |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| Cabinet | Yes | — | 0 | 0 | 0 | 0 | 0 |
| Circuit | Yes | — | 0 | 0 | 0 | 37,754 | 0 |
| Secure Cabinet | Yes | — | 0 | 37,754 | 0 | null | 0 |
| Power | No | Secure Cabinet | 49,892 | 0 | 49,892 | null | 49,892 |
| Space | No | Secure Cabinet | 49,892 | 696,000 | 49,892 | 696,000 | 49,892 |

The two child lines each have `Sales_Quantity__c = 4`, `NetUnitPrice = 12,473`, `NetTotalPrice = 49,892`, and `TotalAdjustmentAmount = 49,892`. The quote `GrandTotal = 99,784` matches their `TotalPrice` sum. The root-only custom MRC rollup excludes them and therefore returns zero. The root-only NRC rollup returns 37,754 from the Secure Cabinet root, while a child Space line has 696,000 in `Cumulative_NRC__c` and `ChargesNRC__c` but is excluded. `ChargesNRC__c` metadata describes it as storing a fee amount. No line-level `NRC__c` value is populated; do not equate null NRC with zero.

## Finding for agent behavior

The screenshot's use of PHP 99,784 as an unqualified “quote grand total” reflects a real standard field, but its answer was incomplete and potentially misleading because it did not read the dedicated custom totals. The user's “zero price” is supported only for the configured **root-line MRC rollup**, which is a real numeric zero; the current evidence does **not** prove that the overall quote price or all charge bases are zero. The agent should disclose the exact scope and the conflict briefly, rather than choose 99,784 merely because it is nonzero or declare a zero overall quote.

Root-only aggregation is confirmed metadata. Whether the child prices should flow into the root cumulative values, or whether the root exclusion is intentional for this transaction, requires pricing/process evidence beyond these fields. No record changes were made.
